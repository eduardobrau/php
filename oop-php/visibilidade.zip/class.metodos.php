<?php
/**
 * Define MinhaClasse
 */
class MinhaClasse
{
    // Declara um construtor p�blico
    //public function __construct() { }
    //Perceba que $mensagem está no escopo global
    //public $mensagem = "Ol� eu sou um metodo p�blico <br />";
    public $mensagem;
    // Declara um m�todo public
    public function meuPublico() {
        return $mensagem;
	}

    // Declara um m�todo protected
    protected function meuProtegido() {
		echo "Ol� eu sou um metodo protegido posso ser acessado dentro
		da classe que fui declarado e por subclasses. <br />" ;
                //$this->meuPrivado();
	}
	
    // Declara um m�todo private
    private function meuPrivado() {
		echo "Ol� eu sou um metodo privado s&oacute; posso ser acessado dentro
			da classe que fui declarado <br />";
	}

    // Esse � public
    public function Foo()
    {
        $this->meuPublico();
        $this->meuProtegido();
        $this->meuPrivado();
    }
}

$minhaclasse = new MinhaClasse;
$minhaclasse->Foo(); // Public, Protected e Private funcionam
$minhaclasse->mensagem = "Este é um teste";
$minhaclasse->meuPublico(); // Funciona

//$minhaclasse->meuProtegido(); Erro Fatal
//$minhaclasse->meuPrivado(); // Erro Fatal